﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCopy
{
    class Polygone
    {
        public Point[] points;

        public Polygone(Point[] points)
        {
            this.points = points;
        }

    }
}
